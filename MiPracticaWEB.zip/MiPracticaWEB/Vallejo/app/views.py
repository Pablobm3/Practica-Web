from django.shortcuts import render,redirect
from .forms import UserInputForm
# Create your views here.
# Por cada página que tengamos crearemos/definiremos una vista.

def home(request):
    if request.method == 'POST':
        form = UserInputForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            return render(request, 'app/inicio.html', {'username': username})
    else:
        form = UserInputForm()
    return render(request,'app/home.html', {'form': form})

def contacto(request):
    return render(request, 'app/contacto.html')

def inicio(request):
    return render(request, 'app/inicio.html'),

# Más adelante accederemos desde aquí a la base de datos.