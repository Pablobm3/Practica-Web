from django import forms

class UserInputForm(forms.Form):
    username = forms.CharField(label='¿Quien eres?')

