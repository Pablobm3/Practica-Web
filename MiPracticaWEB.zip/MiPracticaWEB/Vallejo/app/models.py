from django.db import models

# Create your models here.

class UserInputForm(models.Model):
    text_input = models.TextField()